// Wait 4 seconds, then transition to home.html
setTimeout(() => {
  window.location.href = "home.html";
}, 10000);
